// Demonstration back end only. Deploy this separately from GitHub Pages.
// Never send your STEAM_API_KEY to the browser or commit it to GitHub.
import express from "express";
import cors from "cors";

const app = express();
app.use(cors({ origin: "https://YOUR-GITHUB-USERNAME.github.io" }));

app.get("/api/steam-charts", async (req, res) => {
  const { year, month, region = "US" } = req.query;
  if (!/^\d{4}$/.test(year) || !/^(0?[1-9]|1[0-2])$/.test(month)) {
    return res.status(400).json({ error: "Use a four-digit year and a month from 1 through 12." });
  }

  // Add server-side collection here. Keep any key in your hosting provider's
  // encrypted environment variables, e.g. process.env.STEAM_API_KEY.
  // Return normalized records in the shape used by app.js.
  res.json([
    { chartDate: `${year}-${String(month).padStart(2, "0")}-01`, rank: 1, game: "Example Quest", price: "$39.99", weeks: 4, region }
  ]);
});

app.listen(process.env.PORT || 3000, () => console.log("API running"));
