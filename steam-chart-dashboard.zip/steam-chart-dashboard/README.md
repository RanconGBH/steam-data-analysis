# Steam Chart Explorer

A starter dashboard for collecting and displaying Steam Top Seller chart data by month.

## Run the static dashboard

Open `index.html` in a browser. It starts in **mock mode** so that the table and charts work before an API is available.

To publish the front end on GitHub Pages:

1. Create a GitHub repository and upload the files in this folder.
2. In GitHub, open **Settings → Pages**, select **Deploy from a branch**, and choose `main` and `/ (root)`.
3. After deployment, set `API_URL` in `app.js` to the URL of your separate API service.

## API and key safety

GitHub Pages only serves static files. Do not put a Steam Web API key in `app.js`, HTML, or a GitHub Actions secret exposed to browser code. Host the API separately (for example, Render, Railway, Vercel, or Cloudflare Workers), store `STEAM_API_KEY` there as an environment variable, and allow requests only from your GitHub Pages domain.

`api/example-server.js` is a small demonstration endpoint. Locally, run:

```bash
npm install
npm start
```

Then set `API_URL` in `app.js` to `http://localhost:3000/api/steam-charts`.

## Data contract

The browser expects an array like:

```json
[{"chartDate":"2026-09-01","rank":1,"game":"Example Quest","price":"$39.99","weeks":4}]
```

Use a back-end collector to return normalized weekly records for every Tuesday in the selected month. The public dated chart is a weekly revenue ranking, so analyze chart persistence/rank movement rather than player-count retention.
